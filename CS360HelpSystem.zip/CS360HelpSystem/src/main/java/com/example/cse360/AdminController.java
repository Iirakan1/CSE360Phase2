package main.java.com.example.cse360;

public class AdminController {

}
