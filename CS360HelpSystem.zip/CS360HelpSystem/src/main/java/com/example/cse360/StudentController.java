package main.java.com.example.cse360;

public class StudentController {
    // Future functionality for Student role
}
