package main.java.com.example.cse360;

public enum UserRole {
    STUDENT,
    ADMIN,
    INSTRUCTOR
}
