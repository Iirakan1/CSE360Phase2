/**
 * 
 */
/**
 * 
 */
module main.java.com.example.cse360 {
	requires javafx.controls;
    requires javafx.fxml;

    opens main.java.com.example.cse360 to javafx.fxml;
}